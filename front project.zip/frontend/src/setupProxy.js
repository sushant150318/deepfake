const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/predict',
    createProxyMiddleware({
      target: 'http://localhost:5000/predict', // Change this to your server URL
      changeOrigin: true,
    })
  );
};
