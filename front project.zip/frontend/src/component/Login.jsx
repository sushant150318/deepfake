import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; 
import CryptoJS from 'crypto-js';

const Login = ({ setIsLoggedIn }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate(); 

  const validateEmail = (email) => {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateEmail(email)) {
      setError('Invalid email address');
      return;
    }

    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      const hashedPassword = CryptoJS.SHA256(password).toString();
      if (user.email === email && user.password === hashedPassword) {
        setIsLoggedIn(true);
        alert('Login successful!');
        setEmail('');
        setPassword('');
        setError('');
        navigate('/Home'); 
      } else {
        setError('Invalid email or password');
      }
    } else {
      setError('No user found');
    }
  };

  return (
    <div className="auth-container">
      <h1>Login</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label>Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>
      </form>
      <p>
        Don't have an account? <Link to="/signup">Sign Up</Link>
      </p>
    </div>
  );
};

export default Login;
