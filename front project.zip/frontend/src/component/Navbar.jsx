import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom"; 
import profileImage from '../assets/profileImage.png';

const Navbar = ({ isLoggedIn, setIsLoggedIn }) => {
  const navigate = useNavigate();

  // Function to handle logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate('/login'); 
  };

  return (
    <nav className="navbar">
      <h2 className="logo">
        <Link to="/Home">Deepfake Detection</Link>
      </h2>
      <ul className="nav-links">
        <li>
          <Link to="/overview">Overview</Link>
        </li>
        <li>
          <Link to="/Technology">Technology</Link>
        </li>
        <li>
          <Link to="/About">About us</Link>
        </li>
      </ul>
      <ul className="nav-user">
        {/* Conditionally render login/signup or user profile */}
        {!isLoggedIn ? (
          <>
            <li>
              <Link to="/login">Log In</Link>
            </li>
            <li>
              <Link to="/signup">
                <button className="btn">Sign Up</button>
              </Link>
            </li>
          </>
        ) : (
          <>
            <li>
              <img src={profileImage} alt="Profile" className="profile-image" />
            </li>
            <li>
              <button onClick={handleLogout} className="btn">Logout</button>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
