import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

const Home = () => {
  return (
    <div className="hero-container">
      <div className="hero-main">
        <div className="text-container">
          <h1>Enhancing Security with Deepfake Detection</h1>
          <p>
            Protect your organization from manipulated media and fraudulent
            activities using our advanced deepfake detection technology. We
            provide state-of-the-art solutions to identify and mitigate the
            risks associated with deepfake content.
          </p>
          <Link to="/upload">
            {" "}
            <button className="btn">Try Now</button>
          </Link>
        </div>
        <div className="image-container">
          <img
            className="gif"
            src="https://cdn.dribbble.com/users/3496409/screenshots/7749099/media/e28f5b7f3756d12dddc8a57e0f559219.gif"
            alt="Deepfake Detection Demo"
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
